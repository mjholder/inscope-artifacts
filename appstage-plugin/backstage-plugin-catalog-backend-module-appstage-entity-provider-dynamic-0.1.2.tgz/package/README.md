# backstage-plugin-catalog-backend-module-appstage-entity-provider

The appstage-entity-provider backend module for the catalog plugin.

_This plugin was created through the Backstage CLI_
